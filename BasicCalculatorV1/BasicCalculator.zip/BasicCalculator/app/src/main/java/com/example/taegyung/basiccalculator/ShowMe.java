package com.example.taegyung.basiccalculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by TaeGyung on 2021-12-25.
 */

public class ShowMe extends AppCompatActivity {

    Button subB1;

    protected void onCreate(Bundle saveInstanceState) {

        super.onCreate(saveInstanceState);
        setContentView(R.layout.sub1);

        subB1 = (Button)findViewById(R.id.btn_question);
        subB1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // 현재 실행중인 Activity를 종료한다.
                finish();
            }
        });

    }
}
